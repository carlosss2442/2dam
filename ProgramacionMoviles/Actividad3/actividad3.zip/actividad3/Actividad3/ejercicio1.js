import { Pressable, Text, View, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [text, setText] = useState('Hola');
  const [text1, setText1] = useState('Hola');
  const [text2, setText2] = useState('Hola');
  const [text3, setText3] = useState('Hola');
  const [text4, setText4] = useState('Hola');

  function handleOnpress(text, setText) {
    if (text === 'Hola') {
      setText('Adios');
    } else {
      setText('Hola');
    }
  }

  return (
    <View style={[styles.container, { text: text }]}>
      <Pressable onPress={handleOnpress}>
        <Text
          style={styles.text}
          onPress={() => {
            handleOnpress(text1, setText1);
          }}>
          {text1}
        </Text>
        <Text
          style={styles.text}
          onPress={() => {
            handleOnpress(text2, setText2);
          }}>
          {text2}
        </Text>
        <Text
          style={styles.text}
          onPress={() => {
            handleOnpress(text3, setText3);
          }}>
          {text3}
        </Text>
        <Text
          style={styles.text}
          onPress={() => {
            handleOnpress(text4, setText4);
          }}>
          {text4}
        </Text>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 30,
    marginBottom: 20,
  },
});
