import { Pressable, View, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [colorSquare, setColorSquare] = useState('yellow');
  const [sizeSquare, setSizeSquare] = useState(200);

  function handleOnPress(square) {
    if (square === 1) {
      setColorSquare('green');
      setSizeSquare(sizeSquare + 20);
    } else {
      setColorSquare('yellow');
      setSizeSquare(sizeSquare - 20);
    }
  }

  return (
    <View style={styles.container}>
      <Pressable
        style={[
          styles.square,
          {
            backgroundColor: colorSquare,
            width: sizeSquare,
            height: sizeSquare,
          },
        ]}
        onPress={() => {
          handleOnPress(1);
        }}
      />
      <Pressable
        style={[
          styles.square,
          {
            backgroundColor: colorSquare,
            width: sizeSquare,
            height: sizeSquare,
          },
        ]}
        onPress={() => {
          handleOnPress(2);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  square: { marginTop: -6, width: 200, height: 200, backgroundColor: 'yellow' },
});
