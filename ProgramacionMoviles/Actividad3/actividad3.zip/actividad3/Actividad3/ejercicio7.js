import { TextInput, View, Pressable, Text, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [text, setText] = useState('');
  const [dni, setDni] = useState('');

  function handleOnPress() {
    let id  = text.toString();
    id = id.split('');
    if (text === '') {
      alert('No has introducido nada.');
      setText('');
      setDni('')
    } else if (text.length !== 9) {
      alert('Introduce un DNI con ocho numeros y una letra');
      setText('');
      setDni('')
    } else if (!isNaN(parseInt(id[id.length - 1]))) {
      alert('El DNI tiene que acabar en letra.');
      setDni('');
    } else if (isNaN(text.substring(0, 8))) {
      alert('Introduce un DNI con ocho cifras numéricas.');
      setDni('');
    } else {
      if (dni === '') {
        setDni('DNI correcto: ' + text);
      }
    }
    setText('');
  }
  

  return (
    <View style={styles.container}>
      <Text style={styles.text2}>Validador DNI</Text>
      <TextInput
        style={styles.textInput}
        placeholder="Inserta DNI..."
        onChangeText={(newText) => setText(newText)}
        value={text}
      />
      {dni != '' && (
        <Text style={{ padding: 10, fontSize: 25, marginBottom: 20}}>
         dni correcto: {dni}
        </Text>
      )}
      <Pressable onPress={handleOnPress}>
        <Text style={styles.cuadro}>
          Púlsame!
        </Text>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },

  textInput: {
    height: 50,
    width: 105,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    marginBottom: 20,
    marginTop: 20
  },
  text2: {
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 20,
  },
  cuadro: {
    padding: 15,
    borderRadius: 5,
    boxShadow: 10  ,
    backgroundColor: 'orange',
    fontWeight: 'bold'
  }
});
