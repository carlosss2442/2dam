import { TextInput, View, Pressable, Text, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [text, setText] = useState('');
  const [resultado, setResultado] = useState(null);

  function handleOnPress() {
    if (text === '') {
      alert('No hay nada.');
      setText('');
      setResultado(null);
    } else if (isNaN(text)) {
      alert('Has introducido texto.');
      setText('');
      setResultado(null);
    } else {
      const euros = parseFloat(text);
      const dolares =  euros * 1.08;
      setResultado(dolares.toFixed(2));
      setText('');
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.text2}>Convertirdor de euros - dolares</Text>
      <TextInput
        style={styles.textInput}
        placeholder="Inserta euros"
        keyboardType="numeric"
        onChangeText={(newText) => setText(newText)}
        value={text}
      />
      {resultado != null && (
        <Text style={{ padding: 10, fontSize: 25, marginBottom: 20}}>
          {text}{resultado} dolares
        </Text>
      )}
      <Pressable onPress={handleOnPress}>
        <Text style={[styles.text, { backgroundColor: 'orange', fontWeight: 'bold'}]}>
          Púlsame!
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    height: 40,
    width: 80,
    backgroundColor: 'orange',
    borderRadius: 8,
    padding: 6,
  },
  textInput: {
    height: 50,
    width: 105,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    marginBottom: 20,
    marginTop: 20
  },
  text2: {
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 20,
  },
});
