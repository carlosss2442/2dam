import { TextInput, View, Pressable, Text, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [text, setText] = useState('');

  function handleOnPress() {
    if (text === "") {
      alert('No hay nada.');
    } else if (isNaN(text)) {
      alert('Has introducido texto.');
    } else {
      alert('Has introducido numero.');
    }
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={{ height: 40 }}
        placeholder="Inserta tu texto..."
        onChangeText={(newText) => setText(newText)}
        defaultValue={text}
      />
      <Text style={{ padding: 10, fontSize: 42 }}>{text}</Text>

      <Pressable onPress={handleOnPress}>
        <Text style={[styles.text, { backgroundColor: 'blue' }]}>Púlsame!</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    height: 40,
    width: 80,
    borderRadius: 8,
    padding: 6,
    marginTop: 30,
  },
});
