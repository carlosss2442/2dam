import { Text, Pressable, Image, View, StyleSheet } from 'react-native';
import { useState } from 'react';
export default function App() {
  const [image, setImage] = useState(require('./descarga.jpg'));
  const [image1, setImage1] = useState(require('./descarga.jpg'));
  const [image2, setImage2] = useState(require('./golen.jpeg'));
  const [text, setText] = useState('Messi');
  const [text1, setText1] = useState('Messi');
  const [text2, setText2] = useState('Golem');

  function handleOnpress(image, setImage, text, setText) {
    if (image === require('./descarga.jpg')) {
      setImage(require('./golen.jpeg'));
      setText('Golem');
    } else {
      setImage(require('./descarga.jpg'));
      setText('Messi');
    }
  }

  /*function handleOnText(text,setText) {
    if (text === 'Messi') {
      setText('Golem');
    } else {
      setText('Messi');
    }
  }*/

  return (
    <View style={[styles.containerRow, { text: text }]}>
      <Pressable
        onPress={() => {
          handleOnpress(image1, setImage1, text1, setText1);
        }}>
        <Image style={styles.image} source={image1} />
        <Text style={styles.text}>{text1}</Text>
      </Pressable>
      <Pressable
        onPress={() => {
          handleOnpress(image2, setImage2, text2, setText2);
        }}>
        <Image style={styles.image} source={image2} />
        <Text style={styles.text}>{text2}</Text>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  containerRow: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  image: {
    width: 100,
    height: 100,
  },
});
