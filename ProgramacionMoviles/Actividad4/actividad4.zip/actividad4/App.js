import { StyleSheet, View } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [cicles1] = useState([
    {
      width: 100,
      height: 100,
      borderTopLeftRadius: 100,
      backgroundColor: 'blue',
    },
    {
      width: 100,
      height: 100,
      borderTopRightRadius: 100,
      backgroundColor: 'red',
    },
  ]);

  const [circle2] = useState([
    {
      width: 100,
      height: 100,
      borderBottomLeftRadius: 100,
      backgroundColor: 'red',
    },
    {
      width: 100,
      height: 100,
      borderBottomRightRadius: 100,
      backgroundColor: 'blue',
    },
  ]);


  const [circuless12] = useState([cicles1, circle2]);

const [circulo3] = useState([
  {
      width: 75,
      height: 75,
      borderTopLeftRadius: 75,
      backgroundColor: 'blue',
    },
    {
      width: 75,
      height: 75,
      borderTopRightRadius: 75,
      backgroundColor: 'red',
    },
  ]);

const [circulo4] = useState([
 {
      width: 75,
      height: 75,
      borderBottomLeftRadius: 75,
      backgroundColor: 'red',
    },
    {
      width: 75,
      height: 75,
      borderBottomRightRadius: 75,
      backgroundColor: 'blue',
    },
  ]);

const [circuless34] = useState([circulo3,circulo4])
  
  const [cirulo5] = useState([
 {
      width: 50,
      height: 50,
      borderTopLeftRadius: 50,
      backgroundColor: 'blue',
    },
    {
      width: 50,
      height: 50,
      borderTopRightRadius: 50,
      backgroundColor: 'red',
    },
  ]);

const [circulo6] = useState([
 {
      width: 50,
      height: 50,
      borderBottomLeftRadius: 50,
      backgroundColor: 'red',
    },
    {
      width: 50,
      height: 50,
      borderBottomRightRadius: 50,
      backgroundColor: 'blue',
    },
]);

const [circuless56] = useState([cirulo5,circulo6]);

  return (
    <View style={styles.container}>
      {circuless12.map((row, index) => (
        <View key={index} style={{ flexDirection: 'row' }}>
          {row.map((item, index2) => (
            <View key={index2} style={item} />
          ))}
        </View>
      ))}
      {circuless34.map((row, index) => (
        <View key={index} style={{ flexDirection: 'row' }}>
          {row.map((item, index2) => (
            <View key={index2} style={item} />
          ))}
        </View>
      ))}
      {circuless56.map((row, index) => (
        <View key={index} style={{ flexDirection: 'row' }}>
          {row.map((item, index2) => (
            <View key={index2} style={item} />
          ))}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
