import { StyleSheet, View } from 'react-native';
import { useState } from 'react';
export default function App() {
  const [contents, setContents] = useState([
    { height: 120, width: 120, backgroundColor: 'blue' },
    { height: 250, width: 250, backgroundColor: 'red' },
  ]);

  return (
    <View style={styles.container}>
      {contents.map((square, index) => (
        <View key={index} style={square} />
      ))}
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
