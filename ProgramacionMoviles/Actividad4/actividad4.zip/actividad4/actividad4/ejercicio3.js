import { View, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [triangulo] = useState([
    {
      width: 0,
      height: 0,
      backgroundColor: 'transparent',
      borderStyle: 'solid',
      borderLeftWidth: 50,
      borderRightWidth: 50,
      borderBottomWidth: 100,
      borderLeftColor: 'transparent',
      borderRightColor: 'transparent',
      borderBottomColor: 'blue',
    },
  ]);

  const [square1] = useState([
    { height: 100, width: 100, backgroundColor: 'blue' },
  ]);

  const [square2] = useState([
    { height: 100, width: 100, backgroundColor: 'blue' },
    { height: 100, width: 100, backgroundColor: 'blue' },
  ]);

  // Array de arrays
  const [array] = useState([triangulo, square1, square2]);

  return (
    <View style={styles.container}>
      <View style={{ justifyContent: 'center', alignItems: 'center' }}>
        {array.map((grupo, index) => (
          <View key={index} style={styles.row}>
            {grupo.map((item, ind) => (
              <View key={ind} style={item} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  row: {
    flexDirection:'row', 
    justifyContent: 'center', 
    alignItems: 'center' 
  }
});
