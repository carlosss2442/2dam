import { StyleSheet, View } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [circle1] = useState([
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'red' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'blue' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'green' },
  ]);

  const [circle2] = useState([
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'blue' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'green' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'red' },
  ]);

  const [circle3] = useState([
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'green' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'red' },
    { width: 100, height: 100, borderRadius: 50, backgroundColor: 'blue' },
  ]);

  // array de arrays
  const [circlesss] = useState([circle1, circle2, circle3]);

  return (
    <View style={styles.container}>
      <View style={styles.ciclesStyle}>
        {circlesss.map((item, index) => (
          <View key={index} style={item}>
            {item.map((ele, index2) => (
              <View key={index2} style={ele} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ciclesStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
