import { View, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [square1] = useState([
    { width: 100, height: 100, backgroundColor: 'blue' },
    { width: 100, height: 100, backgroundColor: 'blue' },
  ]);

  const [square2] = useState([
    { width: 100, height: 100, backgroundColor: 'red' },
    { width: 100, height: 100, backgroundColor: 'blue' },
  ]);

  const [square3] = useState([
    { width: 100, height: 100, backgroundColor: 'red' },
    { width: 100, height: 100, backgroundColor: 'red' },
  ]);

  // Array de arrays
  const [squaresss] = useState([square1, square2, square3]);

  return (
    <View style={styles.container}>
    <View style={styles.columnContainer}>
        {squaresss.map((fila, index) => (
          <View key={index} style={styles.row}>
            {fila.map((cuadro, indice) => (
              <View key={indice} style={cuadro} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  columnContainer: {
    flexDirection: 'column', // 👈 organiza verticalmente
    justifyContent: 'center',
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row', // cada fila tiene varios cuadrados en horizontal
    justifyContent: 'center',
    alignItems: 'center',
  },
});
