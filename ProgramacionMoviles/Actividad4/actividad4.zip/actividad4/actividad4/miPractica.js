import { View, Text, StyleSheet } from 'react-native';
import { useState } from 'react';
export default function App() {
  const [squares, setSquares] = useState([
    { width: 100, height: 100, backgroundColor: 'red', marginBottom: 30 },
    { width: 100, height: 100, backgroundColor: 'blue', marginBottom: 30  },
    { width: 100, height: 100, backgroundColor: 'green', marginBottom: 30 },
    { width: 100, height: 100, backgroundColor: 'yellow', marginBottom: 30},
    { width: 100, height: 100, backgroundColor: 'orange',  marginBottom: 30},
    { width: 100, height: 100, backgroundColor: 'pink',  marginBottom: 30},
    { width: 100, height: 100, backgroundColor: 'purple'},
    { width: 100, height: 100, backgroundColor: 'brown'},
    { width: 100, height: 100, backgroundColor: 'black'},
  ]);
  return (
    <View style={styles.container}>
      <View
        style={styles.squaresStyle}>
        {squares.map((item, index) => (
          <View key={index} style={item} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  squaresStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flexWrap: 'wrap',
    flexDirection: 'row',
  },
});
