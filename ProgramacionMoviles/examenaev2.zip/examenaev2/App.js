import { StyleSheet, Text, View } from 'react-native';
import AssetExample from './components/AssetExample';
import { NavigationContainer } from '@react-navigation/native';
import Tab from './Tab/Tab';
import Stack from './Stack/stack';
import Drawer from './Drawer/drawer';
import Modal from './Modal/modal';


export default function App() {
  return (
    <View style={styles.container}>
    <Stack></Stack>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
