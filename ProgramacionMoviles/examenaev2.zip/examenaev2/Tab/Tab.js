import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import ScreenOne from './src/screens/screen1';
import ScreenTwo from './src/screens/screen2';
import Drawer from '../Drawer/drawer'

const Tab = createBottomTabNavigator();
const App = () => (
 
    <Tab.Navigator>
      <Tab.Screen name="TabScreen1" component={ScreenOne} />
      <Tab.Screen name="TabScreen2" component={Drawer} />
    </Tab.Navigator>
   
 
);
export default App;
