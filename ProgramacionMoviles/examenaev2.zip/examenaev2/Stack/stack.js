import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import Screen1 from './src/screens/screen1';
import Screen2 from './src/screens/screen2';
import Tab from '../Tab/Tab'


const Stack = createStackNavigator();

const App = () => (
  <NavigationContainer>
    <Stack.Navigator options="false">
      <Stack.Screen name="Screen 1" component={Screen1} />
      <Stack.Screen name="Screen 2" component={Tab} />
    </Stack.Navigator>
  </NavigationContainer>
);
export default App;
