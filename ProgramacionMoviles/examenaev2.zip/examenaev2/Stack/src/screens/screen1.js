import { StyleSheet, Text, View, Pressable } from 'react-native';
const Screen1 = (props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Pantalla 1</Text>
      <Pressable  style={styles.buton}  onPress={() => props.navigation.navigate('Screen 2')}>
        <Text style={styles.text}>Ir a Pantalla 2</Text>
      </Pressable>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  text: {
    height: 40,
    width: 100,
    color: 'white',
    borderRadius: 8,
    padding: 6,
  },
  buton: {
    backgroundColor: 'black',
    textAlign: 'center',
     alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
  }
});
export default Screen1;
