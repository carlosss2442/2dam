import { StyleSheet, Text, View, Pressable } from 'react-native';
const Screen2 = (props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>TabScreen1</Text>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  text: {
    height: 40,
    width: 100,
    backgroundColor: 'lightblue',
    borderRadius: 8,
    padding: 6,
  },
});
export default Screen2;
