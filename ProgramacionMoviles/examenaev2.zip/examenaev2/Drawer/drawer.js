import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import ScreenOne from './scr/screens/screenOne';
import ScreenTwo from './scr/screens/screenTwo';

const Drawer = createDrawerNavigator();

 const App = () =>  {
  return (
    
      <Drawer.Navigator useLegacyImplementation={false} initialRouteName="DrawerScreen1">
        <Drawer.Screen name="DrawerScreen1" component={ScreenOne} />
        <Drawer.Screen name="DrawerScreen2" component={ScreenTwo} />
      </Drawer.Navigator>
    
  );
}

export default App;
