import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  Image,
  ScrollView,
} from 'react-native';
import { useState } from 'react';
import GetData from '../../../Services/services';

const ScreenTwo = () => {
  const [namePokemon, setNamePokemon] = useState();
  const [image1, setImagen1] = useState([]);

  const buscaPokemon = async () => {
    const data = await GetData(
      `https://pokeapi.co/api/v2/pokemon/${namePokemon}`
    );

    const imagePokemon = data.sprites.front_default;
    setImagen1(imagePokemon);
  };

  const siguiente = async () => {
    const data = await GetData(
      `https://pokeapi.co/api/v2/pokemon/${namePokemon}`
    );

    const imagePokemon1 = data.sprites.front_default;
    setImagen1(imagePokemon1);

    const imagePokemon2 = data.sprites.back_default;
    
    const imagePokemon3 = data.sprites.front_shiny;
    
    const imagePokemon4 = data.sprites.back_shiny;

    if (imagePokemon1 == data.sprites.front_default) {
      setImagen1(imagePokemon2);
    
    } else if (imagePokemon2 == data.sprites.back_default) {
      setImagen1(imagePokemon3);
   
    } else  {
      setImagen1(imagePokemon4);
    }
  };


  const atras = async () => {
      const data = await GetData(
      `https://pokeapi.co/api/v2/pokemon/${namePokemon}`
    );

    const imagePokemon1 = data.sprites.front_default;
    setImagen1(imagePokemon1);

    const imagePokemon2 = data.sprites.back_default;
    
    const imagePokemon3 = data.sprites.front_shiny;
    
    const imagePokemon4 = data.sprites.back_shiny;

    if (imagePokemon2 == data.sprites.back_default) {
      setImagen1(imagePokemon1);
    
    } else if (imagePokemon1 == data.sprites.front_default) {
      setImagen1(imagePokemon3);
    
    } else  {
      setImagen1(imagePokemon4);
    }
  };

  return (
    <>
      <View style={styles.form}>
        <TextInput
          style={{ height: 40 }}
          placeholder="Inserta término de búsqueda"
          onChangeText={(newText) => setNamePokemon(newText)}
          value={namePokemon}
        />
        <Pressable
          style={styles.button}
          onPress={() => {
            buscaPokemon();
          }}>
          <Text style={styles.buttonText}>Buscar Pokémon</Text>
        </Pressable>
        <View styel={{ width: '33%' }}>
          <Image
            style={{
              width: 200,
              height: 200,
            }}
            source={{ uri: image1 }}
          />
        </View>
      </View>
      <View style={styles.container}>
        <ScrollView>
          <View style={styles.carousel}>
            <Pressable style={styles.button} onPress={() => {atras()}}>
              <Text style={styles.buttonText}>Anterior</Text>
            </Pressable>

            <Pressable
              style={styles.button}
              onPress={() => {
                siguiente();
              }}>
              <Text style={styles.buttonText}>Siguiente</Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 35,
    position: 'relative',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: 'black',
    width: '40%',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 40,
  },
  buttonText: {
    color: 'white',
    fontWeight: '400',
    fontSize: 12,
  },
  carousel: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  form: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
export default ScreenTwo;
