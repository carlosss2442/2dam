import { Pressable, StyleSheet, Text, View } from 'react-native';
const Screen1 = (props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Pantalla screen1</Text>
      <Pressable onPress={() => props.navigation.navigate('Screen2')}>
        <Text style={styles.text}>Screen 2</Text>
      </Pressable>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'grey',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontSize: 32, marginBottom: 16 },
  text: {
    height: 40,
    width: 80,
    backgroundColor: 'lightblue',
    borderRadius: 8,
    padding: 6,
  },
});
export default Screen1;
