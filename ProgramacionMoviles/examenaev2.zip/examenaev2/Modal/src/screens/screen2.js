import { Pressable, StyleSheet, Text, View } from 'react-native';

const Screen2 = (props) => {
  
  return (
    <View style={styles.layout}>
      <Text style={styles.title}>Pantalla 2</Text>
      <Pressable onPress={() => props.navigation.goBack()}>
        <Text style={styles.text}>Descartar</Text>
      </Pressable>
    </View>
  );
};


const styles = StyleSheet.create({
  layout: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: { fontSize: 32, marginBottom: 16 },
  text: {
    height: 40,
    width: 80,
    backgroundColor: 'lightblue',
    borderRadius: 8,
    padding: 6,
  },
});
export default Screen2;
