import { View, Pressable, Text, StyleSheet } from 'react-native';
import { useState } from 'react';
export default function App() {
  const [color, setColor] = useState('green');
  const [squareC, setSquareC] = useState('yellow');
  const [ancho, setAncho] = useState(200);
  const [altura, setAltura] = useState(200);
  function handlerOnpress() {
    if (color == 'green') {
      setColor('yellow');
      setSquareC('green');
       setAncho(ancho + 10);
        setAltura(altura + 10);
      if (ancho == 300) {
        setAncho(200);
        setAltura(200);
      }
    } else {
      setColor('green');
      setSquareC('yellow');
      setAncho(ancho + 10);
        setAltura(altura + 10);
      if (ancho == 300) {
        setAncho(200);
        setAltura(200);
      }
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: color }]}>
      <View
        style={[
          styles.square,
          { backgroundColor: squareC },
          { height: altura },
          { width: ancho },
        ]}
      />
      <Pressable onPress={handlerOnpress}>
        <Text style={styles.text}>Púlsame!</Text>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'green',
    alignItems: 'center',
    justifyContent: 'center',
  },
  square: {
    size: '100',
    mt: '-2',
    marginTop: -6,
    width: 200,
    height: 200,
    backgroundColor: 'yellow',
  },
  text: {
    height: 40,
    width: 80,
    backgroundColor: 'blue',
    borderRadius: 8,
    padding: 6,
  },
});
