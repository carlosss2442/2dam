import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
export default function App() {
  let variable = "Hola mundo"
  let content = {
      paragraphOne: "Me llamo carlos",
      paragraphTwo: "Mi apellido Teran"
  };
return (
<View style={styles.container}>
<Text>Estoy aprendiendo a programar.</Text>
<Text>{variable}</Text>
<Text>{content.paragraphOne}</Text>
<Text>{content.paragraphTwo}</Text>
</View>
);
}
const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#fff',
alignItems: 'center',
justifyContent: 'center',
},
});