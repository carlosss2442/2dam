import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Article from './components/article';

export default function App() {
    let content={
    title: "Caracoles",
    paragraphOne: "Hola caracola",
    paragraphTwo: "Adios caracol"
  };

function Articles(){
  let array = [];
  for(let i=0; i < 4 ;i++){
 array.push(<Article key={i.toString()}
 title={content.title}
 paragraphOne= {content.paragraphOne}
 paragraphTwo= {content.paragraphTwo}  ></Article>);
}
  return(
<View>
{array}
</View>
);
}

return(
<View>
<Articles></Articles>
</View>
);
}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: 'blue',
alignItems: 'center',
justifyContent: 'center',
},
title: {
  fontSize: 12,
  fontStyle: 'italic',
  fontWeight: 'bold',
}
});