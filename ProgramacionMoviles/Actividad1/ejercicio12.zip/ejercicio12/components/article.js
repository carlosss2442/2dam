import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
export default function Article({ title, paragraphOne, paragraphTwo }) {
  return (
    <View style={styles.container}>
      <Text>{title}</Text>
      <Text>{paragraphOne}</Text>
      <Text>{paragraphTwo}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'blue',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 12,
    fontStyle: 'italic',
    fontWeight: 'bold',
  },
});