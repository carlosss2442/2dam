import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
export default function App() {
  let variable = "Hola mundo"
  let content = {
      paragraphOne: "Me llamo carlos",
      paragraphTwo: "Mi apellido Teran",
      title: "Programacion de dispositivos moviles"
  };

function Article (){
  return (
<View style={styles.container}>
<Text style={styles.title}>{content.title}</Text>
<Text style={styles.paragraphOne}>{content.paragraphOne}</Text>
<Text>{content.paragraphTwo}</Text>
</View>
);
}}

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#27F5EE',
alignItems: 'center',
justifyContent: 'center',
},
title: {
  fontSize: 12,
  fontStyle: 'italic',
  fontWeight: 'bold',
},
paragraphOne:{
  fontSize: 9,
  fontFamily: 'arial',
  color: 'blue'
}
});







